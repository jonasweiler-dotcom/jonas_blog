<?php
/**
 * Header-Template
 *
 * @package WarmesTagebuch
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#main"><?php esc_html_e( 'Zum Inhalt springen', 'warmes-tagebuch' ); ?></a>

<div class="site">

    <header class="site-header" role="banner">
        <div class="container container-wide">
            <div class="site-header-inner">

                <div class="site-branding">
                    <?php if ( has_custom_logo() ) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <h1 class="site-title">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                                <?php bloginfo( 'name' ); ?>
                            </a>
                        </h1>
                        <?php $description = get_bloginfo( 'description', 'display' ); ?>
                        <?php if ( $description ) : ?>
                            <p class="site-description"><?php echo esc_html( $description ); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <nav class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Hauptmenü', 'warmes-tagebuch' ); ?>">
                    <?php
                    if ( has_nav_menu( 'primary' ) ) {
                        wp_nav_menu(
                            array(
                                'theme_location' => 'primary',
                                'menu_id'        => 'primary-menu',
                                'container'      => false,
                                'depth'          => 1,
                            )
                        );
                    } else {
                        echo '<ul><li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Menü einrichten', 'warmes-tagebuch' ) . '</a></li></ul>';
                    }
                    ?>
                </nav>

            </div>
        </div>
    </header>

    <main id="main" class="site-content" role="main">

<?php
/**
 * 404 Fehlerseite.
 *
 * @package WarmesTagebuch
 */

get_header();
?>

<div class="container">

    <article class="post-card" style="text-align:center;">
        <header class="entry-header" style="border:none; padding:0; margin-bottom:1.5rem;">
            <p class="post-meta" style="justify-content:center;"><?php esc_html_e( 'Fehler 404', 'warmes-tagebuch' ); ?></p>
            <h1 class="entry-title"><?php esc_html_e( 'Diese Seite gibt es leider nicht.', 'warmes-tagebuch' ); ?></h1>
        </header>

        <div class="entry-content">
            <p>
                <?php esc_html_e( 'Vielleicht hast du dich verlaufen, oder die Seite wurde umbenannt. Versuche es über die Startseite oder das Menü.', 'warmes-tagebuch' ); ?>
            </p>
            <p style="margin-top:2rem;">
                <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <?php esc_html_e( 'Zur Startseite', 'warmes-tagebuch' ); ?>
                </a>
            </p>
        </div>
    </article>

</div>

<?php
get_footer();

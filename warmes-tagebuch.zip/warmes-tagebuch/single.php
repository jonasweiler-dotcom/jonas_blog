<?php
/**
 * Template für die Einzelansicht eines Beitrags.
 *
 * @package WarmesTagebuch
 */

get_header();
?>

<div class="container">

    <?php while ( have_posts() ) : the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

            <header class="entry-header">
                <div class="post-meta">
                    <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
                        <?php echo esc_html( get_the_date() ); ?>
                    </time>
                    <span>·</span>
                    <span><?php echo esc_html( get_the_author() ); ?></span>
                    <?php
                    $categories = get_the_category_list( ', ' );
                    if ( $categories ) {
                        echo '<span>·</span><span class="post-categories">' . wp_kses_post( $categories ) . '</span>';
                    }
                    ?>
                </div>
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>

            <?php if ( has_post_thumbnail() ) : ?>
                <div class="entry-thumbnail">
                    <?php the_post_thumbnail( 'large' ); ?>
                </div>
            <?php endif; ?>

            <div class="entry-content">
                <?php
                the_content();

                wp_link_pages(
                    array(
                        'before' => '<div class="page-links">' . esc_html__( 'Seiten:', 'warmes-tagebuch' ),
                        'after'  => '</div>',
                    )
                );
                ?>
            </div>

            <footer class="entry-footer">
                <?php
                $tags = get_the_tag_list( '', ' ' );
                if ( $tags ) {
                    echo '<p class="post-tags">' . esc_html__( 'Schlagwörter: ', 'warmes-tagebuch' ) . wp_kses_post( $tags ) . '</p>';
                }
                ?>
            </footer>

        </article>

        <nav class="post-navigation" aria-label="<?php esc_attr_e( 'Beitrag-Navigation', 'warmes-tagebuch' ); ?>" style="margin-top:3rem; display:flex; justify-content:space-between; gap:1rem; flex-wrap:wrap;">
            <div><?php previous_post_link( '<span style="font-size:0.85rem;color:var(--color-text-muted);">' . esc_html__( '← Vorheriger Beitrag', 'warmes-tagebuch' ) . '</span><br>%link' ); ?></div>
            <div style="text-align:right;"><?php next_post_link( '<span style="font-size:0.85rem;color:var(--color-text-muted);">' . esc_html__( 'Nächster Beitrag →', 'warmes-tagebuch' ) . '</span><br>%link' ); ?></div>
        </nav>

        <?php
        if ( comments_open() || get_comments_number() ) {
            echo '<div style="margin-top:3rem;">';
            comments_template();
            echo '</div>';
        }
        ?>

    <?php endwhile; ?>

</div>

<?php
get_footer();

<?php
/**
 * Warmes Tagebuch - Theme functions
 *
 * @package WarmesTagebuch
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direkten Aufruf verhindern.
}

if ( ! defined( 'WARMES_TAGEBUCH_VERSION' ) ) {
    define( 'WARMES_TAGEBUCH_VERSION', '1.0.0' );
}

/**
 * Theme-Setup: Features registrieren
 */
function warmes_tagebuch_setup() {

    // Übersetzungen laden.
    load_theme_textdomain( 'warmes-tagebuch', get_template_directory() . '/languages' );

    // Automatischer Title-Tag.
    add_theme_support( 'title-tag' );

    // Automatischer RSS-Feed-Link im <head>.
    add_theme_support( 'automatic-feed-links' );

    // Beitragsbilder aktivieren.
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 1200, 630, true );

    // HTML5 statt klassischem Markup.
    add_theme_support(
        'html5',
        array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
    );

    // Block-Editor: Stylesheet und Wide-/Full-Alignment.
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );

    // Custom Logo.
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 80,
            'width'       => 240,
            'flex-height' => true,
            'flex-width'  => true,
        )
    );

    // Menüs registrieren.
    register_nav_menus(
        array(
            'primary' => __( 'Hauptmenü', 'warmes-tagebuch' ),
            'footer'  => __( 'Footer-Menü', 'warmes-tagebuch' ),
        )
    );
}
add_action( 'after_setup_theme', 'warmes_tagebuch_setup' );

/**
 * Stylesheets und Schriften einbinden.
 */
function warmes_tagebuch_enqueue_assets() {
    // Google Fonts: Lora (Serif für Überschriften) + Inter (Sans für Fließtext).
    wp_enqueue_style(
        'warmes-tagebuch-fonts',
        'https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Inter:wght@400;500;600&display=swap',
        array(),
        null
    );

    // Haupt-Stylesheet.
    wp_enqueue_style(
        'warmes-tagebuch-style',
        get_stylesheet_uri(),
        array( 'warmes-tagebuch-fonts' ),
        WARMES_TAGEBUCH_VERSION
    );

    // Kommentar-Antwort-Skript.
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'warmes_tagebuch_enqueue_assets' );

/**
 * Body-Klassen ergänzen.
 */
function warmes_tagebuch_body_classes( $classes ) {
    if ( ! is_singular() ) {
        $classes[] = 'hfeed';
    }
    return $classes;
}
add_filter( 'body_class', 'warmes_tagebuch_body_classes' );

/**
 * Excerpt-Länge anpassen.
 */
function warmes_tagebuch_excerpt_length( $length ) {
    return 30;
}
add_filter( 'excerpt_length', 'warmes_tagebuch_excerpt_length', 999 );

/**
 * Excerpt "more"-Text anpassen.
 */
function warmes_tagebuch_excerpt_more( $more ) {
    return '…';
}
add_filter( 'excerpt_more', 'warmes_tagebuch_excerpt_more' );

/**
 * Pingback-URL nur bei offenen Pings ausgeben.
 */
function warmes_tagebuch_pingback_header() {
    if ( is_singular() && pings_open() ) {
        printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
    }
}
add_action( 'wp_head', 'warmes_tagebuch_pingback_header' );

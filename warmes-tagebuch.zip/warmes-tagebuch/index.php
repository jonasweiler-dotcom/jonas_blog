<?php
/**
 * Hauptindex-Template (Blog-Übersicht)
 *
 * @package WarmesTagebuch
 */

get_header();
?>

<div class="container">

    <?php if ( is_home() && ! is_front_page() ) : ?>
        <header class="site-hero">
            <h1><?php single_post_title(); ?></h1>
        </header>
    <?php endif; ?>

    <?php if ( have_posts() ) : ?>

        <div class="post-list">

            <?php while ( have_posts() ) : the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <a class="post-card-thumb" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </a>
                    <?php endif; ?>

                    <div class="post-meta">
                        <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
                            <?php echo esc_html( get_the_date() ); ?>
                        </time>
                        <?php
                        $categories = get_the_category_list( ', ' );
                        if ( $categories ) {
                            echo '<span>·</span><span class="post-categories">' . wp_kses_post( $categories ) . '</span>';
                        }
                        ?>
                    </div>

                    <h2>
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h2>

                    <div class="excerpt">
                        <?php the_excerpt(); ?>
                    </div>

                    <a class="read-more" href="<?php the_permalink(); ?>">
                        <?php esc_html_e( 'Weiterlesen', 'warmes-tagebuch' ); ?>
                    </a>

                </article>

            <?php endwhile; ?>

        </div><!-- .post-list -->

        <?php
        the_posts_pagination(
            array(
                'mid_size'  => 2,
                'prev_text' => __( '← Zurück', 'warmes-tagebuch' ),
                'next_text' => __( 'Weiter →', 'warmes-tagebuch' ),
                'class'     => 'pagination',
            )
        );
        ?>

    <?php else : ?>

        <article class="post-card">
            <h2><?php esc_html_e( 'Noch keine Beiträge', 'warmes-tagebuch' ); ?></h2>
            <p><?php esc_html_e( 'Hier wird bald der erste Beitrag erscheinen. Schau gerne wieder vorbei!', 'warmes-tagebuch' ); ?></p>
        </article>

    <?php endif; ?>

</div>

<?php
get_footer();

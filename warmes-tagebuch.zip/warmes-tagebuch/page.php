<?php
/**
 * Template für statische Seiten (z.B. Über mich, Impressum, Datenschutz).
 *
 * @package WarmesTagebuch
 */

get_header();
?>

<div class="container">

    <?php while ( have_posts() ) : the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>

            <?php if ( has_post_thumbnail() ) : ?>
                <div class="entry-thumbnail">
                    <?php the_post_thumbnail( 'large' ); ?>
                </div>
            <?php endif; ?>

            <div class="entry-content">
                <?php
                the_content();

                wp_link_pages(
                    array(
                        'before' => '<div class="page-links">' . esc_html__( 'Seiten:', 'warmes-tagebuch' ),
                        'after'  => '</div>',
                    )
                );
                ?>
            </div>

        </article>

        <?php
        if ( comments_open() || get_comments_number() ) {
            echo '<div style="margin-top:3rem;">';
            comments_template();
            echo '</div>';
        }
        ?>

    <?php endwhile; ?>

</div>

<?php
get_footer();

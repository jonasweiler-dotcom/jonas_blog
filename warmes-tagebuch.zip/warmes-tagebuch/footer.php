<?php
/**
 * Footer-Template
 *
 * @package WarmesTagebuch
 */
?>
    </main><!-- .site-content -->

    <footer class="site-footer" role="contentinfo">
        <div class="container container-wide">

            <?php if ( has_nav_menu( 'footer' ) ) : ?>
                <nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer-Menü', 'warmes-tagebuch' ); ?>">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'footer',
                            'menu_id'        => 'footer-menu',
                            'container'      => false,
                            'depth'          => 1,
                        )
                    );
                    ?>
                </nav>
            <?php endif; ?>

            <p class="footer-credits">
                &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
                <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
                · <?php esc_html_e( 'Mit Sorgfalt geschrieben', 'warmes-tagebuch' ); ?>
            </p>

        </div>
    </footer>

</div><!-- .site -->

<?php wp_footer(); ?>
</body>
</html>
